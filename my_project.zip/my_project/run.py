from flask import Flask,render_template,request,jsonify
import joblib
import gzip
import pickle
import pandas as pd

credit_card_model = joblib.load(open('/Users/gowri/Desktop/my_project/credit_card_model.pkl','rb')) 
credit_card_model01= joblib.load(open('/Users/gowri/Desktop/my_project/credit_card_model01.pkl','rb'))
demat_model=joblib.load(open('/Users/gowri/Desktop/my_project/demat_model.pkl','rb'))
model=pickle.load(open('/Users/gowri/Desktop/my_project/model.pkl','rb'))
nmodel=pickle.load(open('/Users/gowri/Desktop/my_project/nmodel.pkl','rb'))
app = Flask(__name__)

@app.route('/')
def home():
       return render_template('index.html')

@app.route("/predict", methods=["POST"])
def predict():
    age = request.form["age"]
    gender = request.form["gender"]
    annualincome = request.form["annualincome"]
    spendingscore = request.form["spendingscore"]

    df=pd.DataFrame({age,gender,annualincome,spendingscore})
     
    prediction1=nmodel.predict(df.T)
    
    if(prediction1=='Silver card'):
        new="Silver Card" 
    elif(prediction1=='Gold card'):
        new="Gold Card" 
    elif(prediction1=='Platinum card'):
        new="Platinum Card"  
    else:
        new="Nothing"
    return new
    

    #return prediction1

     
    #return render_template("result.html", prediction=prediction) 
if __name__ == '__main__':
    app.run(port=5001,debug=True)
