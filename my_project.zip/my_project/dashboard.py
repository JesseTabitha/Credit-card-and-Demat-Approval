import ipywidgets as widgets
from IPython.display import display
import pandas as pd
from flask import Flask, render_template, request
import joblib
from sklearn.preprocessing import MinMaxScaler
import pickle

app = Flask(__name__)

# Load the trained models
cc_model = joblib.load('./model.pkl')
da_model = joblib.load('./demat_model.pkl')

# Define a function to fit and return the scaler
def get_scaler():
    scaler = MinMaxScaler()
    scaler.fit_transform(pd.DataFrame({'Age': [18, 70], 'Income': [0, 200], 'Spending Score': [0, 100]}))
    return scaler

# Call the function to get the fitted scaler
scaler = get_scaler()
# Define the home route
@app.route('/')

def home():
    return render_template('index.html')

# Define the credit card approval route
@app.route('/cc', methods=['GET', 'POST'])
def cc():
    if request.method == 'POST':
        gender = request.form['gender']
        age = float(request.form['age'])
        income = float(request.form['income'])
        score = float(request.form['score'])
        
        # Scale the input values using the fitted scaler
        age_scaled, income_scaled, score_scaled = scaler.transform([[age, income, score]])[0]
        
         # Make the prediction
        prediction = cc_model.predict([[gender, age_scaled, income_scaled, score_scaled]])[0]
        
        # Return the prediction
        if prediction == 1:
            return render_template('cc.html', prediction='Approved')
        else:
            return render_template('cc.html', prediction='Not Approved')
    else:
        return render_template('cc.html')
    

# Define the demat account opening route
@app.route('/da', methods=['GET', 'POST'])
def da():
    if request.method == 'POST':
        # Get the input values from the form
        gender = request.form['gender']
        income = float(request.form['income'])
        score = float(request.form['score'])

        # Check if the input values meet the criteria for demat account opening
        if income > 50 and score < 40:
            prediction = 1
        else:
            prediction = 0

        # Return the prediction
        if prediction == 1:
            return render_template('da.html', prediction='Likely')
        else:
            return render_template('da.html', prediction='Not Likely')
    else:
        return render_template('da.html')

  

if __name__ == '__main__':
    app.run(port=5001,debug=True)