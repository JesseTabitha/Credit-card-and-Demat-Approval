from flask import Flask,render_template,request,jsonify
import joblib
import gzip
import pickle
import pandas as pd

model2=joblib.load(open('/Users/gowri/Desktop/my_project/newmodel1.pkl','rb'))

app = Flask(__name__)

@app.route('/')
def home():
       return render_template('index.html')

@app.route("/predict", methods=["POST"])
def predict():
    age = request.form["age"]
    gender = request.form["gender"]
    annualincome = request.form["annualincome"]
    spendingscore = request.form["spendingscore"]

    ndf=pd.DataFrame({'Gender': gender, 'Age': age, 'Annual Income (k$)': annualincome, 'Spending Score (1-100)': spendingscore},index=[0])
    prediction1=model2.predict(ndf)

    if(prediction1[0]==1):
        return render_template('silop.html')
        #return("approved for silver card")
    elif(prediction1[0]==2):
        return render_template('goldop.html')
        #return("approved for gold card")
    elif(prediction1[0]==3):
        return render_template('platinumop.html')
        #return("approved for platinum card")
    else:
        return render_template('nooutput.html')
        #return("Not approved for credit card")

    
if __name__ == '__main__':
    app.run(port=5001,debug=True)   

