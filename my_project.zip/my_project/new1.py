from flask import Flask,render_template,request,jsonify
import joblib
import gzip
import pickle
import pandas as pd

demat_model=joblib.load(open('/Users/gowri/Desktop/my_project/demat_model1.pkl','rb'))

app = Flask(__name__)

@app.route('/')
def home():
       return render_template('index.html')

@app.route("/predict", methods=["POST"])
def predict():
    gender = request.form["gender"]
    age = request.form["age"]
    annualincome = request.form["annualincome"]
    spendingscore = request.form["spendingscore"]

    ndf=pd.DataFrame({'Gender': gender, 'Age': age, 'Annual Income (k$)': annualincome, 'Spending Score (1-100)': spendingscore},index=[0])
    
    prediction1=demat_model.predict(ndf)

    if prediction1[0] == 1:
      return render_template('DEMATAPPROVED.html')
      #return('The customer is likely to open a demat account.')
    else:
      return render_template('NOTAPPROVED.html')
      #return('The customer is unlikely to open a demat account.')



if __name__ == '__main__':
    app.run(port=5003,debug=True)   
